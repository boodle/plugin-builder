import styles from './../scss/public';

(function() {
    'use strict';

    // CODE GOES HERE!
})();
