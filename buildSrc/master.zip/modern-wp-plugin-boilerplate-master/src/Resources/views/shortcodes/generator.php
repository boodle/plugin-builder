<section id="modern-wp-plugin-boilerplate">
    ### shortcode stuff here ###
</section>