<?php

namespace ModernWpPluginBoilerplate\Exceptions;

class TemplateException extends \Exception
{
}
