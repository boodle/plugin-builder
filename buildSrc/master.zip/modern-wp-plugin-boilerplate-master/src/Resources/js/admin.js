import styles from './../scss/admin';

(function() {
    'use strict';

    // CODE GOES HERE!
})();
